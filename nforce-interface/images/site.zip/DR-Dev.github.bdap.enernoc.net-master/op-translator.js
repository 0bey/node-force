/* op-translator:

    Provide functions to convert data objects between salesforce and client formats.

*/

/* Logger */
var logger = require('winston');

var multer = require('multer');

translateSiteCard = function(cardData, callback){

  // No Translation necessary
  var sfTranslation = cardData;

  handleTranslation(null, sfTranslation, callback);

};

translateContactCard = function(cardData, callback){

  // Contact_Role__c
  var sfRole = JSON.parse(JSON.stringify(cardData.role));
  if(sfRole.Id){

    // Role update filters
    delete sfRole.Site__c;
    delete sfRole.Name;
    delete sfRole.Email__c;

  }
  sfRole.Notify_Authorized_to_Acknowledge__c = "Authorized to acknowledge DR Event Call";

  // Contact__c
  var sfContact = cardData;
  delete cardData.role;
  delete cardData.displayName;

  // Return as array of sf objects
  var sfTranslation = [sfContact, sfRole];

  handleTranslation(null, sfTranslation, callback);

};

translateAttachment = function(attachmentData, callback){
/*
  var Options = {

    ParentId: req.headers.parentid,

    Name: req.file.originalname,

    Body: req.file.buffer.toString('base64'),

    ContentType: req.file.mimetype

  }

  req.body = newAttachment;
*/
},

handleTranslation = function(err, sfTranslation, callback){

  if(err){
    console.error(err.message);
    callback(err);
  }

  callback(null, sfTranslation);

};

module.exports = {


  translatePortalObject: function(cardData, callback){

    if(cardData.attributes.type === "Contact"){

      translateContactCard(cardData, callback);

    }else if(cardData.attributes.type === "Site__c"){

      translateSiteCard(cardData, callback);

    }else if(cardData.attributes.type === "Attachment"){

      translateAttachment(cardData,callback);

    }

  },

  translateSFObject: function(req, res){


  }

}
