/* Import Custom Middleware */
var auth       = require("./op-auth.js");
var translator = require("./op-translator.js");
var force      = require("./op-force.js");
var parser  = require("./op-parser.js");

/* Import Third Party Middleware */
var express     = require('express');
var bodyParser  = require('body-parser');
var http        = require('http');

/* Express Server */
var app = express();

/* Multer Declaration */
var multer = require('multer');
var upload = multer();

/* Express Router */
var apiRoutes = express.Router();

/* Logger */
var logger = require("./log/logger");

/* Morgan */
app.use(require('morgan')({ "stream": logger.stream }));

/* Routes */
apiRoutes.post('/authenticate', auth.authorize);

apiRoutes.post('/portal', [auth.validate, upload.single('file'), parser.processPost]);

apiRoutes.get('/portal', [auth.validate, parser.processGet]);

/* Assign Express Middleware */
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use('/', express.static(__dirname + '/'));
app.use('/', apiRoutes);

// Start the server
var port = process.env.PORT || 3001;
app.listen(port);

logger.info("Winter is coming: http//:localhost:" + port);
