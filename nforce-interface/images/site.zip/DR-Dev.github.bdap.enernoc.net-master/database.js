module.exports = {
  'secret' : 'wowzers',
  'database': 'mongodb://172.21.88.31:27017/'
};
