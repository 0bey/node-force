var logger = require('winston');
logger.emitErrs = true;

const tsFormat = () => (new Date()).toLocaleTimeString();

logger.add(
  logger.transports.File, {
    name: 'log.info',
    level: 'info',
    filename: './log/all-logs.log',
    handleExceptions: true,
    json: false,
    maxsize: 5242880, //5MB
    maxFiles: 5,
    colorize: false,
    timestamp: tsFormat
  });
logger.add(
  logger.transports.Console, {
    name: 'log.debug',
    level: 'debug',
    handleExceptions: true,
    json: false,
    colorize: true,
    timestamp: tsFormat
  });


module.exports = logger;
module.exports.stream = {
    write: function(message, encoding){
        logger.info(message);
    }
};
